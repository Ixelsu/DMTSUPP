<h1 align="center"> 
   🎈 Cilik-Ubot 🎈
</h1>

<p align="center">
  <a href="#"><img src="https://telegra.ph/file/d20fc177ac0cb0136d942.jpg" width="300" height="300"></a> </br>
</p>

## Deploy With Heroku 💌

<p align="left">
<a href="https://telegram.dog/XTZ_HerokuBot?start=Z3JleTQyMy9DaWxpay1VYm90IG1haW4"><img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku" width="200""/</a>  

### Generate  String Sessions

<p align="left">
<a href="https://t.me/StringCilik_Bot"><img src="https://img.shields.io/badge/Generate%20String-blue?style=for-the-badge&logo=telegram" width="175""/</a>  </p>

## Config Vars 📑

- `APP_ID` - Your APP ID. Get it from [my.telegram.org](my.telegram.org)
- `API_HASH` - Your API_HASH. Get it from [my.telegram.org](my.telegram.org)
- `HEROKU_APP_NAME` - Your Heroku app name (Only needed if you're deploying this on Heroku)
- `HEROKU_API_KEY` - Your Heroku API KEY. Get it from [here](https://dashboard.heroku.com/account). (Only needed if you're deploying this on Heroku)
- `SESSION` - Pyrogram string session of your telegram account. Get it from [here](t.me/CilikSupport)

## 👨🏻‍💻 Credits

-  [PyroMan](https://github.com/mrismanaziz/PyroMan-Userbot) : PyroMan-Userbot
-  [TeamDerUntergang](https://github.com/TeamDerUntergang/Telegram-SedenUserBot) : SedenUserBot
-  [TheHamkerCat](https://github.com/TheHamkerCat/WilliamButcherBot) : WilliamButcherBot
-  [TeamYukki](https://github.com/TeamYukki/YukkiMusicBot) : YukkiMusicBot
-  [ITZ-ZAID](https://github.com/ITZ-ZAID) : Zaid-UserBot
-  [Tofikdn](https://github.com/tofikdn) : Tede
-  [Toni](https://github.com/Toni880) : Prime-UserBot

## 📑 License
This repository is license under [GPL-3 License](https://github.com/grey423/Cilik-Ubot/blob/master/LICENSE)
<p align="Left">
  </br>
  <b>Copyright (c) 2022 - grey423 | Cilik-Ubot</b>
</p>
