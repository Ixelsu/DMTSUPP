# Config Vars 📑,

-  Make in Simple Vars.

- `APP_ID` - Your APP ID. Get it from [my.telegram.org](my.telegram.org)
- `API_HASH` - Your API_HASH. Get it from [my.telegram.org](my.telegram.org)
- `HEROKU_APP_NAME` - Your Heroku app name (Only needed if you're deploying this on Heroku)
- `HEROKU_API_KEY` - Your Heroku API KEY. Get it from [here](https://dashboard.heroku.com/account). (Only needed if you're deploying this on Heroku)
- `SESSION1` - Pyrogram string session of your telegram account. Get it from [here](https://t.me/CilikSupport)
