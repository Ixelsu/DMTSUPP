# Cilik-PyroBot

from .config import *
from config.config import BLACKLIST_GCAST
